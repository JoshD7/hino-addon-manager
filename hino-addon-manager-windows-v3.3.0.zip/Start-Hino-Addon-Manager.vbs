Set shell = CreateObject("WScript.Shell")
shell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
shell.Run "pythonw.exe " & Chr(34) & shell.CurrentDirectory & "\HinoAddonManager.py" & Chr(34), 0, False
