@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m pip install --upgrade pyinstaller tkinterdnd2 truststore
if errorlevel 1 (echo Dependency installation failed.& pause & exit /b 1)
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name "HinoAddonManager" --collect-all tkinterdnd2 HinoAddonManager.py
if errorlevel 1 (echo Build failed.& pause & exit /b 1)
echo Windows executable created in dist\HinoAddonManager.exe
pause
