"""Hino Addon Manager - Windows Tkinter GUI, standard library only."""
import json, os, re, shutil, tempfile, threading, urllib.request, urllib.error, zipfile, time, ssl, sys, socket, webbrowser, html
from pathlib import Path
import tkinter as tk
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
except ImportError:
    TkinterDnD = None
    DND_FILES = None
from tkinter import ttk, filedialog, messagebox, simpledialog

APP='Hino Addon Manager'
CONFIG=Path.home()/'.hino-addon-manager.json'
HISTORY=Path.home()/'.hino-addon-manager-history.json'
UA={'User-Agent':'HinoAddonManager/3.3.0','Accept':'application/vnd.github+json'}
MAX_ZIP=650*1024*1024
RARE_SOURCE='CurseForge/RareScanner-Forever'
SOURCE_REGISTRY=Path.home()/'.hino-addon-manager-sources.json'
RARE_URL='https://www.curseforge.com/wow/addons/rarescanner/files/all?gameVersionTypeId=88568&page=1&pageSize=20'

def load_config():
    try: return json.loads(CONFIG.read_text(encoding='utf-8'))
    except Exception: return {'wow':'D:/World of Warcraft/_classic_beta_','sources':{},'installed_tags':{}}
def save_config(c): CONFIG.write_text(json.dumps(c,indent=2),encoding='utf-8')
def read_history():
    try:
        data=json.loads(HISTORY.read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except (OSError,ValueError,TypeError):
        return []

def write_history(event, addons='', detail=''):
    from datetime import datetime
    records=read_history()
    records.insert(0,{'date':datetime.now().strftime('%Y-%m-%d %H:%M'),
                      'event':str(event)[:80], 'addons':str(addons)[:160], 'detail':str(detail)[:300]})
    HISTORY.write_text(json.dumps(records[:250],indent=2),encoding='utf-8')

def load_source_registry():
    """Persistent project identities; never infer a download URL from a title."""
    try:
        value=json.loads(SOURCE_REGISTRY.read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError,TypeError):return {}

def save_source_registry(registry):
    if not isinstance(registry,dict):raise ValueError('Invalid source registry')
    temp=SOURCE_REGISTRY.with_suffix('.json.tmp')
    temp.write_text(json.dumps(registry,indent=2,sort_keys=True),encoding='utf-8')
    temp.replace(SOURCE_REGISTRY)

def identify_source(item, registry=None):
    """Return source evidence without treating a project ID as download permission."""
    registry=registry if registry is not None else load_source_registry()
    name=item['name']
    saved=registry.get(name,{})
    if isinstance(saved,dict) and saved.get('provider') and saved.get('project_id'):
        return {'provider':saved['provider'],'project_id':str(saved['project_id']),
                'evidence':'saved source association','download_authorized':False}
    project=item.get('curse_project_id')
    if project and re.fullmatch(r'\d{1,12}',str(project)):
        return {'provider':'curseforge','project_id':str(project),
                'evidence':'TOC X-Curse-Project-ID','download_authorized':False}
    repo=source_from_metadata(item)
    if repo:return {'provider':'github','project_id':repo,
                    'evidence':'TOC repository URL','download_authorized':False}
    return {'provider':'unknown','project_id':None,'evidence':'no reliable project identifier',
            'download_authorized':False}

def record_source(item, registry=None):
    """Save verified metadata without overwriting an explicit previous association."""
    registry=registry if registry is not None else load_source_registry()
    match=identify_source(item,{})
    if match['provider']=='unknown':return False
    name=item['name']
    if name in registry:return False
    registry[name]={'provider':match['provider'],'project_id':match['project_id'],
                    'evidence':match['evidence']}
    save_source_registry(registry)
    return True

def addon_group(item):
    name=item['name'] if isinstance(item,dict) else str(item)
    if name in ('Questie','QuestieDB'):return 'Questie + QuestieDB'
    if name in ('Bagnon','BagBrother') or name.lower().startswith(('bagnon','bagbrother')):return 'Bagnon family'
    return 'Other addons'

def toc_info(folder):
    tocs=list(folder.glob('*.toc'))
    if not tocs:return None
    data={'name':folder.name,'version':'Unknown','title':folder.name,'interface':'','source':'','source_candidates':[],'curse_project_id':'','part_of':'','dependencies':[],'wowi_id':'','wago_id':''}
    for toc in tocs:
        try:
            for line in toc.read_text(encoding='utf-8-sig',errors='replace').splitlines():
                m=re.match(r'^##\s*(Title|Version|Interface|X-Website|X-Repository|X-GitHub|X-Source|X-Project-URL|X-Curse-Project-ID|X-Part-Of|Dependencies|RequiredDeps|X-WoWI-ID|X-Wago-ID)\s*:\s*(.*)',line,re.I)
                if m:
                    k,v=m.group(1).lower(),m.group(2).strip()
                    if k=='title':data['title']=re.sub(r'\|c[0-9a-fA-F]{8}|\|r','',v)
                    elif k=='version':data['version']=v
                    elif k=='interface':data['interface']=v
                    elif k=='x-curse-project-id' and re.fullmatch(r'\d{1,12}',v):data['curse_project_id']=v
                    elif k=='x-part-of':data['part_of']=v
                    elif k in ('dependencies','requireddeps'):data['dependencies'].extend(x.strip() for x in v.split(',') if x.strip())
                    elif k=='x-wowi-id':data['wowi_id']=v
                    elif k=='x-wago-id':data['wago_id']=v
                    elif k in ('x-website','x-repository','x-github','x-source','x-project-url'):
                        data['source_candidates'].append(v)
                        if not data['source']:data['source']=v
        except OSError:pass
    return data

def resolve_wow(path):
    p=Path(path).expanduser()
    if p.name.lower()=='addons' and p.parent.name.lower()=='interface': return p.parent.parent
    if (p/'Interface'/'AddOns').is_dir():return p
    for sub in ('_classic_beta_','_retail_','_classic_','_classic_era_','_ptr_'):
        if (p/sub/'Interface'/'AddOns').is_dir():return p/sub
    if p.is_dir():
        matches=[q.parent.parent for q in p.glob('*/Interface/AddOns') if q.is_dir()]
        if len(matches)==1:return matches[0]
    return p

def scan(path):
    root=resolve_wow(path)/'Interface'/'AddOns' 
    if not root.is_dir():raise FileNotFoundError(f'AddOns folder not found:\n{root}')
    items=[i for f in sorted(root.iterdir(),key=lambda p:p.name.lower()) if f.is_dir() for i in [toc_info(f)] if i]
    # Only inherit source IDs when a module explicitly names a parent, or a known package relationship is present.
    parents={i['name']:i for i in items if i.get('curse_project_id')}
    for item in items:
        if item.get('curse_project_id'):continue
        name=item['name']
        declared=item.get('part_of','').strip()
        parent=(declared if declared in parents else
                'GearQuestForever' if name.startswith('GearQuestForever_') else
                'Bagnon' if name.startswith('Bagnon_') else
                'Bagnon' if name=='BagBrother' else None)
        if parent in parents:
            item['curse_project_id']=parents[parent]['curse_project_id']
            item['inherited_project_id']=True
    registry=load_source_registry()
    for item in items:
        record_source(item,registry)
        item['source_identity']=identify_source(item,registry)
    return items

def curseforge_url(item):
    project=item.get('curse_project_id','')
    return 'https://www.curseforge.com/wow/addons/'+project if re.fullmatch(r'\d{1,12}',str(project)) else ''

def source_from_metadata(item):
    """Only link explicitly declared GitHub projects, never guessed addon names."""
    candidates=item.get('source_candidates') or [item.get('source','')]
    for value in candidates:
        url=str(value).strip()
        match=re.search(r'(?:https?://)?(?:www\.)?github\.com/([\w.-]+)/([\w.-]+)',url,re.I)
        if match:
            try:return parse_repo(match.group(1)+'/'+match.group(2))
            except ValueError:continue
    return None


def compatible_interfaces(old, new):
    """Require an actual interface intersection, not just a version number."""
    a=set(re.findall(r'\b\d{5,6}\b',old or ''))
    b=set(re.findall(r'\b\d{5,6}\b',new or ''))
    return bool(a and b and a.intersection(b))


def candidate_github_asset(item, release):
    """Conservative candidate selection: single release ZIP and newer version tag."""
    if not release or not release.get('tag'):return None
    assets=[a for a in release.get('assets',[]) if a.get('name','').lower().endswith('.zip') and a.get('browser_download_url')]
    if len(assets)!=1:return None
    local=version_tuple(item.get('version',''))
    remote=version_tuple(release.get('tag',''))
    if not local or not remote or remote<=local:return None
    return assets[0]


def parse_repo(value):
    value=value.strip().removesuffix('.git').rstrip('/')
    m=re.fullmatch(r'(?:https://github\.com/)?([\w.-]+)/([\w.-]+)',value,re.I)
    if not m:raise ValueError('Enter a GitHub repository such as owner/repo or https://github.com/owner/repo')
    return f'{m.group(1)}/{m.group(2)}'

def secure_context():
    """Verify HTTPS with the native Windows trust store where available.

    Never disable TLS verification. On older Python, use the platform SSL
    context and report actionable errors if its CA store is incomplete.
    """
    try:
        import truststore
        return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    except ImportError:
        return ssl.create_default_context()


def secure_open(request, timeout=25):
    try:
        return urllib.request.urlopen(request, timeout=timeout, context=secure_context())
    except urllib.error.URLError as exc:
        if isinstance(getattr(exc, 'reason', None), ssl.SSLCertVerificationError):
            raise RuntimeError('HTTPS certificate validation failed. Run Install-Secure-Connection.bat, then restart the app. '
                               'If the problem continues, update Windows trusted certificates. SSL verification remains enabled. '
                               f'Details: {exc}') from exc
        raise

def test_github_connection():
    req=urllib.request.Request('https://api.github.com/repos/Questie/Questie/releases?per_page=1',headers=UA)
    with secure_open(req,timeout=20) as response:
        data=json.load(response)
    if not isinstance(data,list):
        raise RuntimeError('GitHub returned an unexpected response.')
    return ('GitHub API connection verified with HTTPS certificate validation. ' + ('Latest release: '+str(data[0].get('tag_name','unknown')) if data else 'No releases returned.'))

def official_rarescanner():
    """Read official Forever listing. No unofficial mirrors or unverified downloads."""
    req=urllib.request.Request(RARE_URL,headers={'User-Agent':'Mozilla/5.0 HinoAddonManager/3.3.0','Accept':'text/html'})
    try:
        with secure_open(req,timeout=20) as response:
            page=response.read(3*1024*1024).decode('utf-8','replace')
    except Exception as exc:
        return {'repo':RARE_SOURCE,'tag':'','assets':[],'page':RARE_URL,
                'notice':'Official CurseForge page unavailable; open it in your browser to check Forever releases.'}
    # Only Forever-named releases are eligible. The page may be JS-rendered;
    # failure to parse must never be treated as proof of up-to-date status.
    candidates=re.findall(r'RareScanner[_\s-]*FOREVER[_\s-]*1\.60\.1[._\s-]*b(\d+)',html.unescape(page),re.I)
    if not candidates:
        return {'repo':RARE_SOURCE,'tag':'','assets':[],'page':RARE_URL,
                'notice':'Cannot read Forever releases automatically. Open official CurseForge listing.'}
    build=max(map(int,candidates))
    return {'repo':RARE_SOURCE,'tag':f'1.60.1.b{build}','assets':[], 'page':RARE_URL,
            'notice':'Official Forever release found. Download its ZIP from CurseForge and drag it into this app.'}

def latest(repo):
    if repo==RARE_SOURCE or repo.lower()==RARE_SOURCE:
        return official_rarescanner()
    # GitHub /releases/latest may not resolve workflow-published bundle tags.
    # Read the release list, then choose the newest stable published release.
    endpoints=[f'https://api.github.com/repos/{repo}/releases/latest',
               f'https://api.github.com/repos/{repo}/releases?per_page=20']
    errors=[]
    for endpoint in endpoints:
        try:
            req=urllib.request.Request(endpoint,headers=UA)
            with secure_open(req,timeout=20) as response:
                data=json.load(response)
            releases=data if isinstance(data,list) else [data]
            releases=[r for r in releases if isinstance(r,dict) and not r.get('draft') and not r.get('prerelease')]
            if not releases:raise ValueError('No stable published releases returned')
            # Release list is newest first; prefer the most recent matching combined Questie bundle.
            if repo.lower()=='questie/questie':
                releases=[r for r in releases if re.search(r'v\d+\.\d+\.\d+\+v\d+\.\d+\.\d+',r.get('tag_name',''))]
                if not releases:raise ValueError('No combined Questie release in response')
            if repo.lower()==RARE_SOURCE:
                releases=[r for r in releases if any(re.fullmatch(r'RareScanner_FOREVER_1\.60\.1[._-]?b\d+\.zip',a.get('name',''),re.I) for a in r.get('assets',[]))]
                if not releases:raise ValueError('No Forever-specific ZIP in recent mirror releases. Retail files will not be installed.')
            data=releases[0]
            assets=[a for a in data.get('assets',[]) if a.get('name','').lower().endswith('.zip') and a.get('size',0)<=MAX_ZIP]
            return {'tag':data.get('tag_name',''), 'assets':assets, 'page':data.get('html_url',''), 'name':data.get('name',''), 'repo':repo}
        except Exception as exc:
            errors.append(f'{endpoint.rsplit("/",1)[-1]}: {type(exc).__name__}: {exc}')
    raise RuntimeError('GitHub release lookup failed. '+' | '.join(errors))

def check_cancel(cancelled):
    if cancelled is not None and cancelled.is_set():
        raise DownloadCancelled('Cancelled before installation')


def safe_extract_zip(blob, target, cancelled=None, progress=None):
    """Validate names, CRC and extract ONCE, in cancellable 256 KiB chunks."""
    target=Path(target).resolve()
    with zipfile.ZipFile(blob) as z:
        members=z.infolist()
        files=[i for i in members if not i.is_dir()]
        total=sum(i.file_size for i in files)
        if len(files)>10000 or total>MAX_ZIP:
            raise ValueError('ZIP is too large')
        for i in members:
            name=i.filename.replace('\\','/')
            parts=name.split('/')
            if (name.startswith('/') or re.match(r'^[A-Za-z]:',name) or
                '..' in parts or any(':' in part for part in parts) or
                (i.external_attr>>16)&0o170000==0o120000):
                raise ValueError('Unsafe ZIP path or symbolic link')
        completed=0
        for i in files:
            check_cancel(cancelled)
            dest=(target/i.filename.replace('\\','/')).resolve()
            if target not in dest.parents:
                raise ValueError('ZIP entry escapes extraction folder')
            dest.parent.mkdir(parents=True,exist_ok=True)
            with z.open(i) as incoming, open(dest,'wb') as outgoing:
                while True:
                    check_cancel(cancelled)
                    chunk=incoming.read(256*1024)
                    if not chunk:break
                    outgoing.write(chunk)
                    completed+=len(chunk)
                    if progress:progress(completed,total)
        check_cancel(cancelled)


def backup_base(addons_root):
    """Store backups outside Interface/AddOns, under the WoW client root."""
    root=Path(addons_root).resolve()
    return root.parent.parent/'HinoAddonManager'/'Backups'


def migrate_legacy_backups(addons_root):
    """Move old backups without overwriting or deleting any backup data."""
    root=Path(addons_root).resolve()
    old=root/'_HinoBackups'
    new=backup_base(root)
    if not old.is_dir():
        return
    new.mkdir(parents=True,exist_ok=True)
    for item in old.iterdir():
        destination=new/item.name
        if destination.exists():
            # Keep conflicting legacy backups untouched rather than risk data loss.
            continue
        shutil.move(str(item),str(destination))
    try:
        old.rmdir()  # Only remove the empty legacy directory.
    except OSError:
        pass


def install_staged(folders, addons_root, cancelled=None, progress=None):
    """Copy to hidden destinations before committing; rollback on commit errors.

    Cancellation is honored until commit starts. During the short commit phase,
    cancellation is intentionally deferred to protect installed addons.
    """
    root=Path(addons_root).resolve()
    if not root.is_dir():raise FileNotFoundError('AddOns folder not found')
    folders=list(folders)
    names=[f.name for f in folders]
    if len(set(n.lower() for n in names))!=len(names):
        raise ValueError('Duplicate addon folder names')
    for f in folders:
        if f.is_symlink() or any(child.is_symlink() for child in f.rglob('*')):
            raise ValueError('Addon contains symbolic links: '+str(f))
        if not f.is_dir() or not toc_info(f):
            raise ValueError('Invalid staged addon: '+str(f))
        if f.name in ('.','..','_HinoBackups') or not re.fullmatch(r'[\w .()\-]+',f.name):
            raise ValueError('Unexpected addon folder name: '+f.name)
    stage=root/('_HinoStaging-'+str(time.time_ns()))
    stage.mkdir()
    backed=[]; installed=[]
    backup=backup_base(root)/(time.strftime('%Y%m%d-%H%M%S')+'-'+str(time.time_ns()%1000000))
    try:
        total=sum(p.stat().st_size for f in folders for p in f.rglob('*') if p.is_file())
        done=0
        for f in folders:
            for p in f.rglob('*'):
                check_cancel(cancelled)
                relative=p.relative_to(f)
                dest=stage/f.name/relative
                if p.is_dir():
                    dest.mkdir(parents=True,exist_ok=True)
                elif p.is_file():
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    with open(p,'rb') as inp,open(dest,'wb') as out:
                        while True:
                            check_cancel(cancelled)
                            chunk=inp.read(256*1024)
                            if not chunk:break
                            out.write(chunk);done+=len(chunk)
                            if progress:progress(done,total)
        check_cancel(cancelled)
        # COMMIT: no cancellation checks between moving old and new directories.
        try:
            for f in folders:
                dest=root/f.name
                if dest.exists():
                    backup.mkdir(parents=True,exist_ok=True)
                    previous=backup/f.name
                    if previous.exists():raise FileExistsError(str(previous))
                    dest.rename(previous)
                    backed.append((dest,previous))
                (stage/f.name).rename(dest)
                installed.append(dest)
        except Exception:
            for dest in reversed(installed):
                if dest.exists():shutil.rmtree(dest)
            for dest,previous in reversed(backed):
                if previous.exists():previous.rename(dest)
            raise
        return names,str(backup) if backed else 'No previous files to back up'
    finally:
        shutil.rmtree(stage,ignore_errors=True)


def addon_folders(unpack, cancelled=None, progress=None):
    """Discover addon roots using bounded, cancellable directory traversal."""
    unpack=Path(unpack)
    found=[]
    scanned=0
    for base, dirs, files in os.walk(unpack):
        check_cancel(cancelled)
        scanned+=1
        if scanned>30000:
            raise ValueError('Archive contains too many directories')
        current=Path(base)
        depth=len(current.relative_to(unpack).parts)
        if depth>5:
            dirs[:]=[]
            continue
        tocs=[name for name in files if name.lower().endswith('.toc')]
        if tocs:
            found.append(current)
            dirs[:]=[]
        if progress and scanned%20==0:
            progress(scanned,0)
    if not found:
        raise ValueError('No WoW addon .toc files found in ZIP')
    if progress:progress(scanned,scanned)
    return found

def install_zip(path,addons_root,expected=None):
    root=Path(addons_root).resolve()
    if not root.is_dir():raise FileNotFoundError('AddOns folder not found')
    with tempfile.TemporaryDirectory(prefix='hino-addons-') as td:
        unpack=Path(td)/'unpack';unpack.mkdir()
        safe_extract_zip(path,unpack)
        folders=addon_folders(unpack)
        if expected and expected.lower() not in [f.name.lower() for f in folders]:
            raise ValueError(f'Package does not contain expected addon folder: {expected}.')
        for folder in folders:
            incoming=toc_info(folder)
            previous=toc_info(root/folder.name) if (root/folder.name).is_dir() else None
            if not incoming:raise ValueError('Missing addon TOC: '+folder.name)
            if previous and not compatible_interfaces(previous.get('interface',''),incoming.get('interface','')):
                raise ValueError('Compatibility not verified for '+folder.name+'. Existing and incoming interface codes do not overlap. No files were changed.')
            if not previous and '16001' not in re.findall(r'\b\d{5,6}\b',incoming.get('interface','')):
                raise ValueError('New addon '+folder.name+' does not explicitly declare WoW Forever interface 16001. No files were changed.')
        return install_staged(folders,root)


def version_tuple(v):
    nums=re.findall(r'\d+',v or '')
    return tuple(int(n) for n in nums[:4]) if nums else ()

def classify(item,release):
    if not release or not release.get('tag'):return 'Unable to verify version',None
    if item['name'] in ('Questie','QuestieDB') and re.search(r'v\d+\.\d+\.\d+\+v\d+\.\d+\.\d+',release.get('tag','')):
        assets=[a for a in release['assets'] if re.fullmatch(r'Questie-v[\w.+-]+\.zip',a['name'],re.I)]
        # Prefer official combined package; never guess when multiple plausible packages exist.
        if len(assets)!=1:return 'Review release assets',None
        m=re.search(r'v(\d+\.\d+\.\d+)\+v(\d+\.\d+\.\d+)',release['tag'])
        if not m:return 'Review release version',None
        remote=m.group(1 if item['name']=='Questie' else 2)
        local=item['version']
        if version_tuple(remote)>version_tuple(local):return 'Update available',assets[0]
        return 'Up to date' if version_tuple(remote)==version_tuple(local) else 'Installed newer',None
    if item['name']=='RareScanner' and release.get('repo')==RARE_SOURCE:
        assets=[a for a in release['assets'] if re.fullmatch(r'RareScanner_FOREVER_1\.60\.1[._-]?b\d+\.zip',a.get('name',''),re.I)]
        if not assets:return 'No verified Forever ZIP',None
        # Release tag is the mirror sync timestamp, NOT the addon version.
        def build(a):
            m=re.search(r'1\.60\.1[._-]?b(\d+)',a['name'],re.I)
            return int(m.group(1)) if m else -1
        asset=max(assets,key=build)
        remote=build(asset)
        local_match=re.search(r'1\.60\.1[._-]?b(\d+)',item['version'],re.I)
        if not local_match:return 'Review installed version',None
        local=int(local_match.group(1))
        if remote>local:return 'Update available',asset
        return ('Up to date' if remote==local else 'Installed newer'),None
    asset=candidate_github_asset(item,release)
    if asset:return 'Update available',asset
    return 'No verified update',None

class DownloadCancelled(Exception):
    pass

class DownloadTimeout(Exception):
    pass

def download_asset(asset, target, progress=None, cancelled=None, max_seconds=150, opener=secure_open):
    """Download completely into .part before atomic rename; never modify addons here.

    Socket timeout covers stalled reads, wall-clock deadline covers slow endless streams.
    """
    url=asset.get('browser_download_url','')
    if not (url.startswith('https://github.com/') or url.startswith('https://objects.githubusercontent.com/')):
        raise ValueError('Unexpected download host')
    target=Path(target)
    part=target.with_name(target.name+'.part')
    start=time.monotonic();done=0
    try:
        req=urllib.request.Request(url,headers={'User-Agent':UA['User-Agent']})
        with opener(req,timeout=12) as response, open(part,'wb') as dest:
            final_url=response.geturl() if hasattr(response,'geturl') else url
            from urllib.parse import urlsplit
            host=(urlsplit(final_url).hostname or '').lower()
            if host not in ('github.com','objects.githubusercontent.com','release-assets.githubusercontent.com'):
                raise ValueError('Download redirected to an unexpected host: '+host)
            length=response.headers.get('Content-Length') if hasattr(response,'headers') else None
            total=int(length) if length and length.isdigit() else 0
            if total>MAX_ZIP:raise ValueError('Download exceeds maximum ZIP size')
            while True:
                if cancelled is not None and cancelled.is_set():raise DownloadCancelled('Download cancelled by user')
                if time.monotonic()-start>max_seconds:raise DownloadTimeout(f'Download exceeded {max_seconds} seconds')
                try:chunk=response.read(128*1024)
                except (socket.timeout,TimeoutError) as e:raise DownloadTimeout('No data received before network timeout') from e
                if not chunk:break
                done+=len(chunk)
                if done>MAX_ZIP:raise ValueError('Download too large')
                dest.write(chunk)
                if progress:progress(done,total)
        if cancelled is not None and cancelled.is_set():raise DownloadCancelled('Download cancelled by user')
        if not zipfile.is_zipfile(part):raise ValueError('Downloaded file is not a valid ZIP archive')
        os.replace(part,target)
        return done
    finally:
        if part.exists():part.unlink()

class GUI:
 def __init__(self,root):
    self.root=root;root.title('Hino Addon Manager V3.3.0 · WoW Forever');root.geometry('1220x790');root.minsize(920,640)
    self.cfg=load_config();self.items=[];self.busy=False;self.results={};self.cancel_event=threading.Event();self.update_in_progress=False;self.expanded_addon=None;self.collapsed_groups=set();self.backup_paths=[];self._backup_loaded=False;self._backup_loading=False;self._backup_request=0
    self.bg='#0b0b0d';self.panel='#18181b';self.panel2='#202024';self.fg='#f4f4f5';self.green='#50d6a0';self.muted='#a1a1aa';self.edge='#333338'
    bg=self.bg;panel=self.panel;fg=self.fg;green=self.green;muted=self.muted;edge=self.edge
    root.configure(bg=bg)
    style=ttk.Style();style.theme_use('clam')
    style.configure('Treeview',background=panel,foreground=fg,fieldbackground=panel,rowheight=44,borderwidth=0,font=('Segoe UI',10))
    style.map('Treeview',background=[('selected','#214638')],foreground=[('selected','#ffffff')])
    style.configure('Treeview.Heading',background='#242428',foreground='#d4d4d8',relief='flat',font=('Segoe UI',10,'bold'),padding=(9,12))
    style.configure('TButton',font=('Segoe UI',10),padding=(12,10),background='#29292e',foreground=fg,borderwidth=0)
    style.map('TButton',background=[('active','#3b3b42'),('disabled','#202024')],foreground=[('disabled','#777780')])
    style.configure('Primary.TButton',font=('Segoe UI',10,'bold'),padding=(16,12),background=green,foreground='#091710')
    style.map('Primary.TButton',background=[('active','#7be7b9')])
    style.configure('Horizontal.TProgressbar',troughcolor='#29292e',background=green,borderwidth=0)
    self.shell=tk.Frame(root,bg=bg);self.shell.pack(fill='both',expand=True)
    sidebar=tk.Frame(self.shell,bg='#111114',width=215,highlightbackground='#242428',highlightthickness=1)
    sidebar.pack(side='left',fill='y');sidebar.pack_propagate(False)
    tk.Label(sidebar,text='HINO  /',bg='#111114',fg=green,font=('Segoe UI',20,'bold'),anchor='w').pack(fill='x',padx=20,pady=(26,0))
    tk.Label(sidebar,text='ADDON MANAGER',bg='#111114',fg=fg,font=('Segoe UI',11,'bold'),anchor='w').pack(fill='x',padx=20,pady=(0,27))
    self.nav_buttons={}
    for key,title in [('dashboard','⌂  Dashboard'),('addons','▦  My Addons'),('updates','↓  Updates'),('backups','▣  Backups'),('history','◷  History'),('settings','⚙  Settings')]:
        btn=tk.Button(sidebar,text=title,anchor='w',font=('Segoe UI',11),bg='#111114',fg='#c8c8cf',activebackground='#242428',activeforeground=green,bd=0,relief='flat',padx=18,pady=13,command=lambda k=key:self.show_page(k),cursor='hand2')
        btn.pack(fill='x',padx=9,pady=2);self.nav_buttons[key]=btn
    tk.Label(sidebar,text='WOW FOREVER  •  WINDOWS',bg='#111114',fg='#777780',font=('Segoe UI',8)).pack(side='bottom',pady=18)
    main=tk.Frame(self.shell,bg=bg);main.pack(side='left',fill='both',expand=True)
    header=tk.Frame(main,bg=bg);header.pack(fill='x',padx=24,pady=(22,13))
    self.page_title=tk.StringVar(value='Dashboard')
    tk.Label(header,textvariable=self.page_title,bg=bg,fg=fg,font=('Segoe UI',23,'bold')).pack(side='left')
    ttk.Button(header,text='Open AddOns',command=self.open_folder).pack(side='right',padx=(8,0))
    ttk.Button(header,text='Rescan',command=self.refresh).pack(side='right')
    self.pages={}
    content=tk.Frame(main,bg=bg);content.pack(fill='both',expand=True,padx=24)
    for key in ('dashboard','addons','updates','backups','history','settings'):
        self.pages[key]=tk.Frame(content,bg=bg)
    self.path=tk.StringVar(value=self.cfg.get('wow','D:/World of Warcraft/_classic_beta_'))
    self.overview=tk.StringVar(value='Scanning addons...')
    # Dashboard: compact summary and clear actions.
    dash=self.pages['dashboard']
    tk.Label(dash,text='Your WoW Forever addons, all in one place.',bg=bg,fg=muted,font=('Segoe UI',11)).pack(anchor='w',pady=(0,16))
    summary=tk.Frame(dash,bg=bg);summary.pack(fill='x')
    self.installed_text=tk.StringVar(value='—');self.updates_text=tk.StringVar(value='—');self.backup_text=tk.StringVar(value='0')
    for i,(caption,var) in enumerate((('INSTALLED ADDONS',self.installed_text),('VERIFIED UPDATES',self.updates_text),('BACKUPS',self.backup_text))):
        card=tk.Frame(summary,bg=panel,padx=19,pady=15,highlightbackground=edge,highlightthickness=1)
        card.grid(row=0,column=i,sticky='ew',padx=(0,10) if i<2 else 0)
        tk.Label(card,text=caption,bg=panel,fg=muted,font=('Segoe UI',9,'bold')).pack(anchor='w')
        tk.Label(card,textvariable=var,bg=panel,fg=green if i==1 else fg,font=('Segoe UI',25,'bold')).pack(anchor='w',pady=(5,0))
        summary.grid_columnconfigure(i,weight=1,uniform='summary')
    actions=tk.Frame(dash,bg=bg);actions.pack(fill='x',pady=(22,18))
    ttk.Button(actions,text='Check for updates',style='Primary.TButton',command=self.check_all).pack(side='left',padx=(0,10))
    ttk.Button(actions,text='Update available addons',command=self.update_all).pack(side='left',padx=(0,10))
    ttk.Button(actions,text='Install ZIP',command=self.local_zip).pack(side='left')
    dash_addons_header=tk.Frame(dash,bg=bg);dash_addons_header.pack(fill='x',pady=(5,10))
    tk.Label(dash_addons_header,text='MY ADDONS',bg=bg,fg=fg,font=('Segoe UI',12,'bold')).pack(side='left')
    ttk.Button(dash_addons_header,text='View all addons  →',command=lambda:self.show_page('addons')).pack(side='right')
    self.addon_cards=tk.Frame(dash,bg=bg);self.addon_cards.pack(fill='x')
    self.dashboard_more=tk.StringVar(value='')
    tk.Label(dash,textvariable=self.dashboard_more,bg=bg,fg=muted,font=('Segoe UI',10),anchor='w').pack(fill='x',pady=(8,0))
    # WowUp-inspired compact, sortable table. Keep the Hino dashboard and theme.
    addons=self.pages['addons']
    searchrow=tk.Frame(addons,bg=bg);searchrow.pack(fill='x',pady=(0,12))
    tk.Label(searchrow,text='WoW Forever  •  Installed addons',bg=bg,fg=green,font=('Segoe UI',11,'bold')).pack(side='left',padx=(0,16))
    self.search_text=tk.StringVar()
    tk.Entry(searchrow,textvariable=self.search_text,bg=self.panel2,fg=fg,insertbackground=fg,relief='flat',font=('Segoe UI',11)).pack(side='left',fill='x',expand=True,ipady=8)
    ttk.Button(searchrow,text='Check Updates',style='Primary.TButton',command=self.check_all).pack(side='left',padx=(10,6))
    ttk.Button(searchrow,text='Update All',command=self.update_all).pack(side='left')
    tk.Label(addons,text='Select a row to view details, check its source or install a verified update. Double-click to open details.',bg=bg,fg=muted,font=('Segoe UI',9)).pack(anchor='w',pady=(0,9))
    tablebox=tk.Frame(addons,bg=bg);tablebox.pack(fill='both',expand=True)
    self.tree=ttk.Treeview(tablebox,columns=('title','version','interface','source','status'),show='headings',selectmode='browse')
    self.table_sort=('title',False)
    for col,label,width in [('title','ADDON',280),('version','INSTALLED',115),('interface','INTERFACE',100),('source','PROVIDER',140),('status','STATUS',210)]:
        self.tree.heading(col,text=label,command=lambda c=col:self.sort_addons(c))
        self.tree.column(col,width=width,minwidth=85,stretch=col in ('title','status'))
    scroll=ttk.Scrollbar(tablebox,orient='vertical',command=self.tree.yview)
    self.tree.configure(yscrollcommand=scroll.set)
    scroll.pack(side='right',fill='y');self.tree.pack(side='left',fill='both',expand=True)
    self.tree.bind('<Double-1>',lambda e:self.show_selected_details())
    self.search_text.trace_add('write',lambda *_:self.render_addon_list())
    addon_actions=tk.Frame(addons,bg=bg);addon_actions.pack(fill='x',pady=13)
    for title,command in [('Addon details',self.show_selected_details),('Check selected',self.check),('Update selected',self.update),('Open provider',self.open_selected_provider),('Link sources',self.autolink),('Set GitHub source',self.set_source)]:
        ttk.Button(addon_actions,text=title,command=command).pack(side='left',padx=(0,7))
    # Updates: update workflow, release information and manual RareScanner access.
    upd=self.pages['updates']
    tk.Label(upd,text='Only verified compatible updates are installed automatically.',bg=bg,fg=muted,font=('Segoe UI',11)).pack(anchor='w',pady=(0,18))
    ubox=tk.Frame(upd,bg=panel,padx=20,pady=20,highlightbackground=edge,highlightthickness=1);ubox.pack(fill='x')
    top=tk.Frame(ubox,bg=panel);top.pack(fill='x')
    tk.Label(top,text='Addon updates',bg=panel,fg=fg,font=('Segoe UI',15,'bold')).pack(side='left')
    self.update_count_badge=tk.StringVar(value='0 available')
    tk.Label(top,textvariable=self.update_count_badge,bg='#26382f',fg=green,padx=12,pady=5,font=('Segoe UI',10,'bold')).pack(side='right')
    tk.Label(ubox,text='Check compatible releases, then review before installing. Related addon modules are updated together when their package source is verified.',bg=panel,fg=muted,wraplength=820,justify='left').pack(anchor='w',pady=(9,14))
    ur=tk.Frame(ubox,bg=panel);ur.pack(fill='x')
    ttk.Button(ur,text='Check for updates',style='Primary.TButton',command=self.check_all).pack(side='left',padx=(0,10))
    self.install_updates_button=ttk.Button(ur,text='Install updates',command=self.update_all,state='disabled')
    self.install_updates_button.pack(side='left')
    self.update_detail=tk.StringVar(value='Check for updates to see available versions.')
    tk.Label(upd,textvariable=self.update_detail,bg=bg,fg=muted,justify='left',wraplength=850,font=('Segoe UI',10)).pack(anchor='w',pady=(12,8))
    update_container=tk.Frame(upd,bg=bg);update_container.pack(fill='both',expand=True,pady=(0,8))
    self.update_canvas=tk.Canvas(update_container,bg=bg,highlightthickness=0)
    update_scroll=ttk.Scrollbar(update_container,orient='vertical',command=self.update_canvas.yview)
    self.update_canvas.configure(yscrollcommand=update_scroll.set)
    update_scroll.pack(side='right',fill='y');self.update_canvas.pack(side='left',fill='both',expand=True)
    self.update_list=tk.Frame(self.update_canvas,bg=bg)
    self.update_window=self.update_canvas.create_window((0,0),window=self.update_list,anchor='nw')
    self.update_list.bind('<Configure>',lambda e:self.update_canvas.configure(scrollregion=self.update_canvas.bbox('all')))
    self.update_canvas.bind('<Configure>',lambda e:self.update_canvas.itemconfigure(self.update_window,width=e.width))
    self.update_canvas.bind('<MouseWheel>',lambda e:(self.update_canvas.yview_scroll(-int(e.delta/120),'units'),'break')[1])
    # Backups: browse the actual safe location and restore.
    backups=self.pages['backups']
    tk.Label(backups,text='Backups are stored outside Interface\\AddOns.',bg=bg,fg=muted,font=('Segoe UI',11)).pack(anchor='w',pady=(0,12))
    self.backup_location=tk.StringVar()
    tk.Label(backups,textvariable=self.backup_location,bg=panel,fg=fg,padx=14,pady=13,anchor='w',wraplength=730,justify='left').pack(fill='x')
    backup_actions=tk.Frame(backups,bg=bg);backup_actions.pack(fill='x',pady=14)
    ttk.Button(backup_actions,text='Restore backup',style='Primary.TButton',command=self.restore_backup).pack(side='left',padx=(0,9))
    ttk.Button(backup_actions,text='Open backup folder',command=self.open_backups).pack(side='left',padx=(0,9))
    ttk.Button(backup_actions,text='Refresh backups',command=self.refresh_backups).pack(side='left')
    self.backup_list=tk.Listbox(backups,bg=panel,fg=fg,selectbackground='#214638',relief='flat',font=('Segoe UI',11),height=9,activestyle='none')
    self.backup_list.pack(fill='x',pady=(0,10))
    ttk.Button(backup_actions,text='Delete selected backup',command=self.delete_backup).pack(side='left',padx=(9,0))
    tk.Label(backups,text='Select a backup above to restore or delete it. Deleting a backup cannot be undone.',bg=bg,fg=muted,font=('Segoe UI',9)).pack(anchor='w')
    # History is a local, append-only record of successful operations and errors.
    hist=self.pages['history']
    tk.Label(hist,text='Recent addon installs, updates and restores. Stored on this PC.',bg=bg,fg=muted,font=('Segoe UI',11)).pack(anchor='w',pady=(0,14))
    ttk.Button(hist,text='Refresh history',command=self.render_history).pack(anchor='w',pady=(0,12))
    self.history_list=tk.Listbox(hist,bg=panel,fg=fg,selectbackground='#214638',relief='flat',font=('Segoe UI',11),activestyle='none')
    self.history_list.pack(fill='both',expand=True)
    # Settings: no more technical buttons cluttering dashboard.
    settings=self.pages['settings']
    tk.Label(settings,text='GAME LOCATION',bg=bg,fg=muted,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(0,7))
    location=tk.Frame(settings,bg=panel,padx=12,pady=12);location.pack(fill='x')
    tk.Entry(location,textvariable=self.path,bg='#242428',fg=fg,insertbackground=fg,relief='flat',font=('Segoe UI',10)).pack(side='left',fill='x',expand=True,ipady=8)
    ttk.Button(location,text='Browse',command=self.browse).pack(side='left',padx=(9,0))
    ttk.Button(location,text='Save & scan',command=self.refresh).pack(side='left',padx=(8,0))
    tk.Label(settings,text='UPDATE PREFERENCES',bg=bg,fg=muted,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(24,9))
    self.auto_check=tk.BooleanVar(value=self.cfg.get('auto_check',True))
    tk.Checkbutton(settings,text='Automatically check linked addon sources on launch and every 6 hours',variable=self.auto_check,command=self.save_preferences,bg=bg,fg=fg,selectcolor='#242428',activebackground=bg,activeforeground=fg,font=('Segoe UI',10)).pack(anchor='w')
    tk.Label(settings,text='All installed folders are scanned; only identified sources can be checked online. Downloads require verified compatibility.',bg=bg,fg=muted).pack(anchor='w',pady=(4,0))
    tk.Label(settings,text='ADVANCED',bg=bg,fg=muted,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(24,9))
    advanced=tk.Frame(settings,bg=bg);advanced.pack(fill='x')
    ttk.Button(advanced,text='Test GitHub connection',command=self.test_connection).pack(side='left',padx=(0,9))
    ttk.Button(advanced,text='Link known sources',command=self.autolink).pack(side='left')
    # Shared drop zone and progress footer visible on every page.
    self.drop=tk.Label(main,text='↓  Drop downloaded addon ZIP files here  •  or use Install ZIP',bg='#19251f',fg=green,font=('Segoe UI',10,'bold'),pady=12,highlightbackground='#2b493b',highlightthickness=1)
    self.drop.pack(fill='x',padx=24,pady=(9,10))
    if DND_FILES:
        for target in (root,self.drop):
            target.drop_target_register(DND_FILES);target.dnd_bind('<<Drop>>',self.handle_drop)
    else:self.drop.configure(text='Install ZIP from Dashboard  •  optional drag-and-drop: install tkinterdnd2')
    progressrow=tk.Frame(main,bg=bg);progressrow.pack(fill='x',padx=24,pady=(0,10))
    self.progress=ttk.Progressbar(progressrow,mode='determinate',maximum=100)
    self.progress.pack(side='left',fill='x',expand=True,padx=(0,12))
    self.progress_label=tk.StringVar(value='Ready')
    tk.Label(progressrow,textvariable=self.progress_label,bg=bg,fg=green,width=30,anchor='w').pack(side='left')
    self.cancel_button=ttk.Button(progressrow,text='Cancel',command=self.cancel_download,state='disabled');self.cancel_button.pack(side='left')
    self.status=tk.StringVar(value='Ready to scan your addons.')
    tk.Label(main,textvariable=self.status,bg=panel,fg=muted,anchor='w',wraplength=920,padx=24,pady=12,font=('Segoe UI',9)).pack(fill='x')
    self.show_page('dashboard')
    root.after(100,self.refresh)
    if self.auto_check.get():root.after(3000,self.check_all)
    root.after(6*60*60*1000,self.periodic_update_check)

 def periodic_update_check(self):
    # Schedule the next pass even if this pass finds an ongoing operation.
    self.root.after(6*60*60*1000,self.periodic_update_check)
    if self.auto_check.get() and not self.busy and self.items:
        self.check_all()

 def show_page(self,key):
    for page in self.pages.values():page.pack_forget()
    self.pages[key].pack(fill='both',expand=True)
    if key=='history' and hasattr(self,'history_list'):self.render_history()
    self.page_title.set({'dashboard':'Dashboard','addons':'My Addons','updates':'Updates','backups':'Backups','history':'History','settings':'Settings'}[key])
    for k,btn in self.nav_buttons.items():btn.configure(bg='#26382f' if k==key else '#111114',fg=self.green if k==key else '#c8c8cf')
    if key=='backups' and not self._backup_loaded:self.refresh_backups()

 def save_preferences(self):
    self.cfg['auto_check']=bool(self.auto_check.get());save_config(self.cfg)

 def refresh_backups(self):
    """Read backup metadata on a worker, then update Tk only on the UI thread."""
    if self._backup_loading:return
    self._backup_loading=True
    self._backup_request+=1
    request=self._backup_request
    self.backup_location.set('Loading backups…')
    wow_path=self.path.get()
    def worker():
        try:
            root=resolve_wow(wow_path)/'Interface'/'AddOns'
            folder=backup_base(root)
            paths=sorted((p for p in folder.iterdir() if p.is_dir()),key=lambda p:p.name,reverse=True) if folder.exists() else []
            rows=[]
            for path in paths:
                addons=[p.name for p in path.iterdir() if p.is_dir() and toc_info(p)]
                date=path.name[:8];clock=path.name[9:15]
                readable=f'{date[6:8]}/{date[4:6]}/{date[:4]}  {clock[:2]}:{clock[2:4]}:{clock[4:6]}' if len(date)==8 and date.isdigit() and len(clock)==6 and clock.isdigit() else path.name
                rows.append(readable+'  •  '+(', '.join(addons) if addons else 'No addon folders detected'))
            result=(folder,paths,rows,None)
        except Exception as exc:
            result=(None,[],[],str(exc))
        def apply():
            if request!=self._backup_request:return
            folder,paths,rows,error=result
            self._backup_loading=False
            if error:
                self.backup_location.set('Unable to list backups: '+error)
                return
            self.backup_location.set(str(folder))
            self.backup_paths=paths
            self.backup_list.delete(0,'end')
            for row in rows:self.backup_list.insert('end',row)
            self.backup_text.set(str(len(paths)))
            self._backup_loaded=True
        self.root.after(0,apply)
    threading.Thread(target=worker,daemon=True).start()

 def delete_backup(self):
    if self.busy:messagebox.showwarning(APP,'Wait until the current operation finishes.');return
    selection=self.backup_list.curselection()
    if not selection:messagebox.showinfo(APP,'Select a backup first.');return
    path=self.backup_paths[selection[0]]
    root=backup_base(resolve_wow(self.path.get())/'Interface'/'AddOns').resolve()
    if path.resolve().parent!=root:messagebox.showerror(APP,'Invalid backup location.');return
    if not messagebox.askyesno(APP,'Permanently delete this backup?\n\n'+path.name+'\n\nThis cannot be undone.'):return
    try:shutil.rmtree(path);self.refresh_backups();self.status.set('Deleted backup '+path.name)
    except Exception as exc:messagebox.showerror(APP,'Could not delete backup: '+str(exc))

 def open_backups(self):
    folder=backup_base(resolve_wow(self.path.get())/'Interface'/'AddOns')
    folder.mkdir(parents=True,exist_ok=True)
    if hasattr(os,'startfile'):os.startfile(folder)
    else:messagebox.showinfo(APP,str(folder))

 def addon_status(self,item):
    status=self.results.get(item['name'],{}).get('status')
    if status:return status
    if item['name']=='RareScanner':return 'Update status unknown · manual verification'
    return ('Not checked · GitHub source linked' if self.cfg.get('sources',{}).get(item['name']) else ('CurseForge identified · automatic checks unavailable' if item.get('curse_project_id') else 'Source not identified · update status unknown'))

 def scroll_addons(self,event,direction=None):
    if direction is None:
        direction=-1 if event.delta>0 else 1
        if abs(event.delta)>=120:direction*=max(1,abs(event.delta)//120)
    self.addon_canvas.yview_scroll(int(direction),'units')
    return 'break'

 def bind_addon_scroll(self,widget):
    # Bind the wheel on cards and their children, not globally across pages.
    widget.bind('<MouseWheel>',self.scroll_addons)
    widget.bind('<Button-4>',lambda e:self.scroll_addons(e,-1))
    widget.bind('<Button-5>',lambda e:self.scroll_addons(e,1))
    for child in widget.winfo_children():self.bind_addon_scroll(child)

 def provider_for(self,item):
    repo=self.cfg.get('sources',{}).get(item['name'],'')
    if repo==RARE_SOURCE:return 'CurseForge'
    if repo:return 'GitHub'
    if item.get('curse_project_id'):return 'CurseForge'
    return 'Unidentified'

 def sort_addons(self,column):
    old,reverse=self.table_sort
    self.table_sort=(column,not reverse if column==old else False)
    self.render_addon_list()

 def render_addon_list(self):
    if not hasattr(self,'tree'):return
    selected=self.tree.selection()
    chosen=selected[0] if selected else None
    needle=self.search_text.get().strip().lower()
    rows=[]
    for idx,item in enumerate(self.items):
        status=self.addon_status(item)
        provider=self.provider_for(item)
        values=(item['title'],item['version'],item['interface'],provider,status)
        if needle and needle not in ' '.join(str(v) for v in values).lower()+' '+item['name'].lower():continue
        rows.append((idx,values))
    col,reverse=self.table_sort
    index=('title','version','interface','source','status').index(col)
    rows.sort(key=lambda row:row[1][index].casefold(),reverse=reverse)
    self.tree.delete(*self.tree.get_children())
    for idx,values in rows:
        tag='available' if values[4]=='Update available' else ('current' if values[4]=='Up to date' else 'normal')
        self.tree.insert('','end',iid=str(idx),values=values,tags=(tag,))
    self.tree.tag_configure('available',foreground='#50d6a0')
    self.tree.tag_configure('current',foreground='#b6dcca')
    if chosen and self.tree.exists(chosen):self.tree.selection_set(chosen)

 def open_selected_provider(self):
    item=self.selected()
    if not item:return
    url=curseforge_url(item)
    if url:webbrowser.open(url);return
    repo=self.cfg.get('sources',{}).get(item['name'],'')
    if repo==RARE_SOURCE:self.open_rarescanner()
    elif repo:webbrowser.open('https://github.com/'+repo)
    else:messagebox.showinfo(APP,'No verified provider URL was found in this addon metadata.')

 def show_selected_details(self):
    item=self.selected()
    if not item:return
    project=item.get('curse_project_id') or 'Not provided'
    repo=self.cfg.get('sources',{}).get(item['name']) or 'Not linked'
    note=self.compatibility_note(item)
    messagebox.showinfo(APP,f"{item['title']}\n\nFolder: {item['name']}\nInstalled version: {item['version']}\nInterface: {item['interface'] or 'Unknown'}\nProvider: {self.provider_for(item)}\nCurseForge project ID: {project}\nGitHub source: {repo}\nStatus: {self.addon_status(item)}"+(('\n\n'+note) if note else ''))

 def toggle_group(self,group):
    if group in self.collapsed_groups:self.collapsed_groups.remove(group)
    else:self.collapsed_groups.add(group)
    self.render_addon_list()

 def compatibility_note(self,item):
    raw=str(item.get('interface',''))
    values=[int(x) for x in re.findall(r'\b\d{5,6}\b',raw)]
    if not values:return 'Compatibility unknown: this addon does not declare a numeric interface version.'
    if 16001 not in values:
        return 'Compatibility not confirmed: addon metadata does not list WoW Forever interface 16001. This is not proof the addon is broken.'
    return ''

 def render_update_groups(self):
    if not hasattr(self,'update_list'):return
    for child in self.update_list.winfo_children():child.destroy()
    buckets={'Updates available':[],'Up to date':[],'Manual / not verified':[]}
    for item in self.items:
        status=self.addon_status(item)
        if status=='Update available':bucket='Updates available'
        elif status=='Up to date':bucket='Up to date'
        else:bucket='Manual / not verified'
        buckets[bucket].append((item,status))
    count=len(buckets['Updates available'])
    if hasattr(self,'update_count_badge'):
        self.update_count_badge.set(f'{count} available')
        self.install_updates_button.configure(state='normal' if count and not self.busy else 'disabled')
    for title,entries in buckets.items():
        heading=tk.Label(self.update_list,text=f'{title.upper()}  ·  {len(entries)}',bg=self.bg,fg=self.green if title=='Updates available' else self.fg,font=('Segoe UI',11,'bold'),anchor='w')
        heading.pack(fill='x',pady=(13,7))
        if not entries:
            tk.Label(self.update_list,text='None',bg=self.bg,fg=self.muted,anchor='w').pack(fill='x',pady=(0,5))
        for item,status in entries:
            line=tk.Frame(self.update_list,bg=self.panel,padx=12,pady=9,highlightbackground=self.edge,highlightthickness=1)
            line.pack(fill='x',pady=2)
            tk.Label(line,text=item['name']+'   ·   v'+item['version'],bg=self.panel,fg=self.fg,font=('Segoe UI',10,'bold'),anchor='w').pack(side='left')
            tk.Label(line,text=status,bg=self.panel,fg=self.green if status in ('Up to date','Update available') else self.muted,font=('Segoe UI',9)).pack(side='right')
    self.update_canvas.configure(scrollregion=self.update_canvas.bbox('all'))

 def toggle_addon(self,name,idx):
    self.expanded_addon=None if self.expanded_addon==name else name
    self.tree.selection_set(str(idx))
    self.render_addon_list()

 def render_history(self):
    if not hasattr(self,'history_list'):return
    self.history_list.delete(0,'end')
    records=read_history()
    if not records:self.history_list.insert('end','No recorded activity yet. Future installs and updates will appear here.')
    for rec in records:
        self.history_list.insert('end',f"{rec.get('date','')}  |  {rec.get('event','')}  |  {rec.get('addons','')}  {rec.get('detail','')[:90]}")

 def render_cards(self):
    for child in self.addon_cards.winfo_children():child.destroy()
    # Dashboard is a preview, not an unbounded list.
    preview=[]
    groups={}
    for item in self.items:groups.setdefault(addon_group(item),[]).append(item)
    for group in ('Questie + QuestieDB','Bagnon family','Other addons'):
        preview.extend(groups.get(group,[])[:2])
    preview=preview[:5]
    for item in preview:
        card=tk.Frame(self.addon_cards,bg=self.panel,padx=15,pady=11,highlightbackground=self.edge,highlightthickness=1)
        card.pack(fill='x',pady=4)
        row=tk.Frame(card,bg=self.panel);row.pack(fill='x')
        tk.Label(row,text=(item['name'] if item['name']=='Questie' else item['title']),bg=self.panel,fg=self.fg,font=('Segoe UI',11,'bold'),anchor='w').pack(side='left')
        tk.Label(row,text='v'+item['version'],bg=self.panel,fg=self.muted,font=('Segoe UI',10)).pack(side='right')
        status=self.addon_status(item)
        tk.Label(card,text=status,bg=self.panel,fg=self.green if status=='Up to date' else self.muted,font=('Segoe UI',9),anchor='w').pack(fill='x',pady=(4,0))
    self.dashboard_more.set(f'Showing {len(preview)} of {len(self.items)} addons across related groups. View all addons for the complete list.' if len(self.items)>len(preview) else 'All installed addons shown.')
    self.installed_text.set(str(len(self.items)))
    self.updates_text.set(str(sum(1 for x in self.results.values() if x.get('status')=='Update available')))
    self.render_addon_list()
    self.render_update_groups()

 def open_rarescanner(self):
    webbrowser.open(RARE_URL)
    self.status.set('Official RareScanner Forever files opened in browser. Download the Forever ZIP, then drag it into the app. Never choose Retail.')

 def autolink(self):
    linked=[]
    for item in self.items:
        if item['name'] in ('Questie','QuestieDB'):
            self.cfg.setdefault('sources',{})[item['name']]='Questie/Questie'
            linked.append(item['name'])
        elif item['name']=='RareScanner':
            self.cfg.setdefault('sources',{})[item['name']]=RARE_SOURCE
            linked.append(item['name'])
        elif item['name']!='HinoCompanion':
            repo=source_from_metadata(item)
            if repo and not self.cfg.setdefault('sources',{}).get(item['name']):
                self.cfg['sources'][item['name']]=repo
                linked.append(item['name'])
    save_config(self.cfg);self.refresh()
    self.status.set(f"Linked {len(linked)} addon folders; identified {sum(bool(i.get('curse_project_id')) for i in self.items)} CurseForge project IDs. CurseForge downloads remain manual.")

 def test_connection(self):
    if self.busy:return
    self.status.set('Testing secure connection to GitHub...')
    def done(result,error):
        self.busy=False
        if error:
            self.status.set('GitHub connection FAILED: '+error)
            messagebox.showerror(APP,'Secure GitHub connection failed:\n\n'+error)
        else:
            self.status.set(result)
            messagebox.showinfo(APP,result)
    self.task(test_github_connection,done)

 def check_all(self):
    if self.busy:return
    for item in self.items:
        if item['name'] in ('Questie','QuestieDB'):
            self.cfg.setdefault('sources',{})[item['name']]='Questie/Questie'
        elif item['name']=='RareScanner':
            self.cfg.setdefault('sources',{})[item['name']]=RARE_SOURCE
        elif item['name']!='HinoCompanion' and not self.cfg.setdefault('sources',{}).get(item['name']):
            repo=source_from_metadata(item)
            if repo:self.cfg['sources'][item['name']]=repo
    save_config(self.cfg)
    repos=sorted(set(self.cfg.get('sources',{}).get(x['name'],'') for x in self.items)-{''})
    if not repos:
        self.autolink();repos=sorted(set(self.cfg.get('sources',{}).get(x['name'],'') for x in self.items)-{''})
    self.status.set(f'Scanned {len(self.items)} installed addon folders; checking {len(repos)} distinct linked GitHub source(s) ...')
    def work():
        out={}
        for repo in repos:
            try:out[repo]=latest(repo)
            except Exception as e:out[repo]={'error':str(e)}
        return out
    def done(out,err):
        self.busy=False
        if err:self.status.set('Check failed: '+err);return
        self.results={}
        count=0
        for idx,item in enumerate(self.items):
            repo=self.cfg.get('sources',{}).get(item['name'],'')
            rel=out.get(repo,{})
            if not repo:continue
            if 'error' in rel:
                self.tree.set(str(idx),'status','Check failed') if self.tree.exists(str(idx)) else None;self.results[item['name']]={'status':'Unable to verify version' if item['name']=='RareScanner' else 'Check failed'};continue
            status,asset=classify(item,rel)
            self.results[item['name']]={'release':rel,'asset':asset,'status':status}
            if self.tree.exists(str(idx)):self.tree.set(str(idx),'status',status)
            if status=='Update available':count+=1
        failures=[f'{repo}: {result["error"]}' for repo,result in out.items() if 'error' in result]
        self.overview.set(f'{len(self.items)} addons installed  •  {count} updates available')
        self.update_detail.set(f'{count} update candidate(s). Downloaded packages must pass compatibility checks before installation.')
        self.render_cards()
        self.status.set(('CHECK FAILED — '+' | '.join(failures)) if failures else f'Scanned {len(self.items)} addon folders; checked {len(repos)} linked GitHub source(s); {count} verified update candidate(s). Unlinked and CurseForge-only projects were NOT checked online.')
        if failures:messagebox.showwarning(APP,'Update check failed:\n\n'+'\n'.join(failures))
    self.task(work,done)

 def cancel_download(self):
    if self.update_in_progress:
        self.cancel_event.set()
        self.progress_label.set('Cancelling...')
        self.status.set('Cancellation requested. Finishing current small read; installation will not start if cancelled.')

 def report_progress(self,label,done,total):
    def ui():
        if not self.update_in_progress:return
        mb=done/(1024*1024)
        if total:
            pct=min(100,int(done*100/total))
            self.progress.configure(value=pct)
            self.progress_label.set(f'{label}: {pct}% ({mb:.1f} MB)')
        else:
            self.progress.configure(value=0)
            self.progress_label.set(f'{label}: {mb:.1f} MB downloaded')
    try:self.root.after(0,ui)
    except RuntimeError:pass

 def report_stage(self,label,done,total):
    def ui():
        if not self.update_in_progress:return
        pct=min(100,int(done*100/total)) if total else 0
        self.progress.configure(value=pct)
        self.progress_label.set(f'{label}: {pct}%')
        self.status.set(label+' — installed addons are preserved until installation is prepared.')
    try:self.root.after(0,ui)
    except RuntimeError:pass

 def report_folder_scan(self,done,total):
    def ui():
        if not self.update_in_progress:return
        self.progress.configure(value=100 if total else 0)
        self.progress_label.set(f'Checking folders: {done} scanned' if not total else f'Found addon folders ({done} scanned)')
    try:self.root.after(0,ui)
    except RuntimeError:pass

 def update_all(self, only_names=None):
    if self.busy:return
    candidates=[x for x in self.items if self.results.get(x['name'],{}).get('status')=='Update available' and (only_names is None or x['name'] in only_names)]
    if not candidates:
        messagebox.showinfo(APP,'No verified automatic updates available. GitHub-based addons with a declared source can update automatically after compatibility checks. Some providers do not offer direct downloads.');return
    groups={}
    for x in candidates:
        repo=self.cfg['sources'].get(x['name'])
        groups.setdefault(repo,[]).append(x)
    desc='\n'.join(f'{repo}: '+', '.join(i['name'] for i in items) for repo,items in groups.items())
    if not messagebox.askyesno(APP,'Close WoW completely. Install these updates?\n\n'+desc+'\n\nRareScanner is updated separately using official CurseForge Forever ZIP files.\n\nBackups are created outside AddOns.'):return
    jobs=[]
    for repo,items in groups.items():
        result=self.results[items[0]['name']]
        jobs.append((repo,result['release'],result['asset'],[i['name'] for i in items]))
    wow_root=resolve_wow(self.path.get())/'Interface'/'AddOns'
    self.cancel_event.clear();self.update_in_progress=True
    self.cancel_button.configure(state='normal');self.progress.configure(value=0)
    self.progress_label.set('Connecting...');self.status.set('Downloading updates; installed addons are unchanged until all downloads pass validation.')
    def work():
        # Stage each bundle exactly once. Never extract the same archive twice.
        with tempfile.TemporaryDirectory(prefix='hino-staged-updates-') as td:
            extracted=[]
            for i,(repo,rel,asset,names) in enumerate(jobs):
                check_cancel(self.cancel_event)
                z=Path(td)/f'bundle-{i}.zip'
                self.report_stage('Downloading '+repo,0,100)
                download_asset(asset,z,progress=lambda n,t,label=repo:self.report_progress(label,n,t),cancelled=self.cancel_event,max_seconds=150)
                check_cancel(self.cancel_event)
                unpack=Path(td)/f'unpack-{i}';unpack.mkdir()
                self.report_stage('Extracting '+repo,0,100)
                safe_extract_zip(z,unpack,cancelled=self.cancel_event,
                    progress=lambda n,t,label=repo:self.report_stage('Extracting '+label,n,t))
                self.report_stage('Checking addon folders',0,100)
                folders=addon_folders(unpack,cancelled=self.cancel_event,
                    progress=lambda n,t:self.report_folder_scan(n,t))
                found={f.name for f in folders}
                if not set(names).issubset(found):
                    raise ValueError('Package missing expected addons: '+', '.join(set(names)-found))
                if repo not in ('Questie/Questie',RARE_SOURCE):
                    # Never let a third-party package install extra addon folders.
                    if found!=set(names):
                        raise ValueError('Update package folder mismatch. Expected: '+', '.join(names)+'; found: '+', '.join(sorted(found)))
                    for folder in folders:
                        original=next((item for item in self.items if item['name']==folder.name),None)
                        info=toc_info(folder)
                        if not original or not info or not compatible_interfaces(original.get('interface',''),info.get('interface','')):
                            raise ValueError('Update is not verified for this WoW client: '+folder.name+' (interface mismatch)')
                        if version_tuple(info.get('version',''))<=version_tuple(original.get('version','')):
                            raise ValueError('ZIP does not contain a newer addon version: '+folder.name)
                if repo==RARE_SOURCE and found!={'RareScanner'}:
                    raise ValueError('Unexpected RareScanner package folders: '+', '.join(sorted(found)))
                if repo=='Questie/Questie' and found!={'Questie','QuestieDB'}:
                    raise ValueError('Unexpected Questie bundle folders: '+', '.join(sorted(found)))
                extracted.append((repo,rel,folders))
            check_cancel(self.cancel_event)
            outcomes=[]
            for repo,rel,folders in extracted:
                self.report_stage('Preparing installation '+repo,0,100)
                result=install_staged(folders,wow_root,cancelled=self.cancel_event,
                    progress=lambda n,t,label=repo:self.report_stage('Preparing '+label,n,t))
                outcomes.append((repo,rel['tag'],result))
            return outcomes
    def done(out,err):
        self.busy=False;self.update_in_progress=False;self.expanded_addon=None;self.collapsed_groups=set();self.backup_paths=[]
        self.cancel_button.configure(state='disabled')
        if err:
            self.progress_label.set('Cancelled' if 'cancel' in err.lower() else 'Failed')
            self.progress.configure(value=0)
            self.status.set('Update stopped: '+err+'. Check addon versions before retrying.')
            write_history('Update stopped',', '.join(x['name'] for x in candidates),err)
            if 'cancel' not in err.lower():messagebox.showerror(APP,'Update stopped:\n'+err)
            return
        self.progress.configure(value=100);self.progress_label.set('Installation complete')
        for repo,tag,_ in out:
            for x in self.items:
                if self.cfg['sources'].get(x['name'])==repo:self.cfg.setdefault('installed_tags',{})[x['name']]=tag
        save_config(self.cfg)
        for repo,tag,res in out:write_history('Automatic update',', '.join(res[0]),f'{tag} · backup {res[1]}')
        self.refresh()
        self.status.set('Updates installed successfully. Scan completed.')
        messagebox.showinfo(APP,'Updates installed.\n\n'+'\n'.join(f'{r}: {tag} | Backup: {res[1]}' for r,tag,res in out))
    self.task(work,done)

 def restore_backup(self):
    root=resolve_wow(self.path.get())/'Interface'/'AddOns'
    backups=backup_base(root)
    try:migrate_legacy_backups(root)
    except OSError as e:
        messagebox.showwarning(APP,'Could not move old backups: '+str(e))
    if not backups.is_dir():messagebox.showinfo(APP,'No backups found.');return
    choice=str(self.backup_paths[self.backup_list.curselection()[0]]) if self.backup_list.curselection() and self.backup_paths else filedialog.askdirectory(initialdir=str(backups),title='Choose a Hino backup folder')
    if not choice:return
    chosen=Path(choice).resolve()
    if backups.resolve() not in chosen.parents or not chosen.is_dir():messagebox.showerror(APP,'Select a folder inside HinoAddonManager/Backups.');return
    folders=[f for f in chosen.iterdir() if f.is_dir() and toc_info(f)]
    if not folders:messagebox.showerror(APP,'No addon folders in selected backup.');return
    if not messagebox.askyesno(APP,'Close WoW first. Restore '+', '.join(f.name for f in folders)+'? Current versions will be backed up again.'):return
    try:
        with tempfile.TemporaryDirectory() as td:
            archive=Path(td)/'restore.zip'
            with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
                for f in folders:
                    for child in f.rglob('*'):
                        if child.is_file():z.write(child,child.relative_to(chosen))
            result=install_zip(archive,root)
        write_history('Backup restored',', '.join(result[0]),str(chosen))
        self.refresh();messagebox.showinfo(APP,'Restored: '+', '.join(result[0])+'\nPrevious versions backed up to '+result[1])
    except Exception as e:messagebox.showerror(APP,str(e))
 def browse(self):
    d=filedialog.askdirectory(initialdir=self.path.get());
    if d:self.path.set(d);self.refresh()
 def selected(self):
    sel=self.tree.selection()
    if not sel:messagebox.showinfo(APP,'Select an addon first.');return None
    return self.items[int(sel[0])]
 def refresh(self):
    try:
        migrate_legacy_backups(resolve_wow(self.path.get())/'Interface'/'AddOns')
    except OSError:
        pass  # A locked legacy backup can still be restored after moving it manually.
    self.cfg['wow']=str(resolve_wow(self.path.get()));self.path.set(self.cfg['wow'])
    self.cfg.setdefault('sources',{})['RareScanner']=RARE_SOURCE
    try:self.items=scan(self.path.get())
    except Exception as e:self.status.set(str(e));return
    for item in self.items:
        if item['name'] in ('Questie','QuestieDB'):
            self.cfg.setdefault('sources',{})[item['name']]='Questie/Questie'
        elif item['name'] not in ('RareScanner','HinoCompanion') and not self.cfg.setdefault('sources',{}).get(item['name']):
            repo=source_from_metadata(item)
            if repo:self.cfg['sources'][item['name']]=repo
    save_config(self.cfg)
    self.tree.delete(*self.tree.get_children())
    for i,item in enumerate(self.items):
        repo=self.cfg.get('sources',{}).get(item['name'],'')
    self.overview.set(f'{len(self.items)} addons installed')
    self.results={}
    self.render_cards()
    self._backup_loaded=False
    if not self._backup_loading:self.refresh_backups()
    self.status.set(f"{len(self.items)} addon folders detected; {sum(bool(i.get('curse_project_id')) for i in self.items)} have CurseForge project IDs. Automatic installs require verified download access.")
 def set_source(self):
    item=self.selected()
    if not item:return
    if item['name']=='RareScanner':
        messagebox.showinfo(APP,'RareScanner uses the official CurseForge Forever listing. Use the RareScanner Forever releases button.');return
    prev=self.cfg.get('sources',{}).get(item['name'],'')
    value=simpledialog.askstring('Link GitHub source',f'GitHub repository for {item["name"]}:\n(e.g. owner/repo)\n\nLeave empty to unlink.',initialvalue=prev,parent=self.root)
    if value is None:return
    try:repo=parse_repo(value) if value.strip() else ''
    except Exception as e:messagebox.showerror(APP,str(e));return
    if repo:self.cfg.setdefault('sources',{})[item['name']]=repo
    else:self.cfg.setdefault('sources',{}).pop(item['name'],None)
    save_config(self.cfg);self.refresh()
 def task(self,work,done):
    if self.busy:return
    self.busy=True
    def runner():
        try:r=work();self.root.after(0,lambda:done(r,None))
        except Exception as e:
            error=f'{type(e).__name__}: {e}'
            self.root.after(0,lambda error=error:done(None,error))
    threading.Thread(target=runner,daemon=True).start()
 def check(self):
    item=self.selected()
    if not item:return
    repo=self.cfg.get('sources',{}).get(item['name'])
    if not repo:messagebox.showinfo(APP,'Link a source first.');return
    if item['name']=='RareScanner':
        self.open_rarescanner();return
    self.status.set('Checking '+repo+' ...')
    def done(result,error):
        self.busy=False
        if error:
            self.status.set('Check failed: '+error)
            messagebox.showerror(APP,'Update check failed:\n\n'+error)
            return
        tag=result['tag'];self.cfg.setdefault('latest',{})[item['name']]=result;save_config(self.cfg)
        installed=self.cfg.get('installed_tags',{}).get(item['name'])
        note='Installed by Hino Manager' if installed else 'Installed version not verified against release tag'
        self.status.set(f'{item["name"]}: GitHub latest {tag}; local TOC version {item["version"]}. {note}. {len(result["assets"])} ZIP assets. Review before updating.')
        idx=next((i for i,v in enumerate(self.items) if v['name']==item['name']),None)
        if idx is not None and self.tree.exists(str(idx)):self.tree.set(str(idx),'status','Latest: '+tag)
    self.task(lambda:latest(repo),done)
 def update(self):
    item=self.selected()
    if not item:return
    if item['name']=='RareScanner':self.open_rarescanner();return
    if self.results.get(item['name'],{}).get('status')!='Update available':
        messagebox.showinfo(APP,'No verified update is ready for this addon. Run Check Updates first. CurseForge identification alone does not authorise automatic downloads.')
        return
    if item['name'] in ('Questie','QuestieDB'):
        self.update_all({'Questie','QuestieDB'})
    else:self.update_all({item['name']})

 def handle_drop(self,event):
    paths=[Path(x) for x in self.root.tk.splitlist(event.data)]
    self.install_files(paths)

 def install_files(self,paths):
    if self.busy:return
    paths=[p for p in paths if p.is_file() and p.suffix.lower()=='.zip']
    if not paths:
        messagebox.showerror(APP,'Drop one or more downloaded .zip addon files.');return
    if not messagebox.askyesno(APP,'Close WoW completely before installing.\n\nInstall '+str(len(paths))+' ZIP(s)? Existing addon folders will be backed up.'):
        return
    root=resolve_wow(self.path.get())/'Interface'/'AddOns'
    self.status.set('Installing '+str(len(paths))+' addon ZIP(s) ...')
    def work():
        out=[]
        for path in paths:
            try:out.append((path.name,install_zip(path,root),None))
            except Exception as e:out.append((path.name,None,str(e)))
        return out
    def done(out,error):
        self.busy=False
        if error:messagebox.showerror(APP,error);return
        for name,result,install_error in out:
            write_history('ZIP installed' if result else 'ZIP failed',', '.join(result[0]) if result else name,str(result[1]) if result else install_error)
        self.refresh()
        lines=[name+': '+('Installed '+', '.join(result[0]) if result else 'FAILED: '+err) for name,result,err in out]
        self.status.set(' | '.join(lines)[:800])
        messagebox.showinfo(APP,'Addon installation results:\n\n'+'\n'.join(lines))
    self.task(work,done)

 def local_zip(self):
    f=filedialog.askopenfilename(filetypes=[('ZIP archives','*.zip')]);
    if not f:return
    self.install_files([Path(f)])
 def open_folder(self):
    p=resolve_wow(self.path.get())/'Interface'/'AddOns'
    if p.is_dir():os.startfile(p) if hasattr(os,'startfile') else None
    else:messagebox.showerror(APP,'Folder not found: '+str(p))

if __name__=='__main__':
    root=TkinterDnD.Tk() if TkinterDnD else tk.Tk();GUI(root);root.mainloop()
