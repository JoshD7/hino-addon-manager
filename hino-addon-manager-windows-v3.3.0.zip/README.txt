HINO ADDON MANAGER V3.1.0 — Hino + WowUp Hybrid
================================================

START
1. Extract all files to a NEW folder (do not run from inside the ZIP).
2. Close any older Hino window.
3. Double-click Start-Hino-Addon-Manager.vbs for no console window.
   If nothing happens, run Start-Hino-Addon-Manager.bat to see Python errors.
4. Check Settings for the correct WoW Forever folder, then Rescan.

NEW IN V3.0
- Compact sortable My Addons table: addon, installed version, interface,
  provider and update status. Search matches all columns.
- Check Updates and Update All at the top of My Addons.
- Addon details and Open provider actions for the selected row.
- Update selected now uses the same checked, staged, backed-up install
  pipeline as Update All, rather than downloading an arbitrary GitHub ZIP.
- Manual ZIP installs verify the incoming TOC interface against the
  installed addon (or require interface 16001 for a new addon), and use
  staged install with rollback.
- Existing Dashboard, Updates, Backups, History, Settings and no-console
  launcher remain available.

CURSEFORGE / WOW FOREVER
- CurseForge project IDs in .toc metadata are recognised, but automatic
  CurseForge release queries and downloads are NOT implemented.
- The provider column means "identified", NOT "download available".
- GitHub update candidates are only installed after ZIP content validation.
- Do NOT use Retail ZIP files. Do NOT update while WoW is running.
- Existing addons are not deleted when upgrading Hino itself.

SAFE UPDATE WORKFLOW
1. Check Updates.
2. Select an addon and use Update selected, or use Update All.
3. Close WoW, review the confirmation, then proceed.
4. Hino validates addon folders and interfaces before replacing files.
5. Existing files are backed up outside Interface/AddOns.

OPTIONAL
Install-Secure-Connection.bat installs truststore/certifi for secure HTTPS.
Install-DragDrop-Dependency.bat installs optional drag-and-drop support.
Build-Windows-EXE.bat builds a Windows executable (requires PyInstaller).

NOTES
This build was syntax-tested and package-tested in Linux. Windows GUI
runtime and actual network installs must be tested on your Windows PC.

NEW IN V3.1.0
- Persistent source identity registry (~/.hino-addon-manager-sources.json).
- Recognizes explicit CurseForge project IDs and GitHub repository URLs in TOC metadata.
- Source identities are evidence, NOT authorization for downloading CurseForge files.
- Rejects staged addon trees containing symbolic links.
- Existing conservative compatibility checks, backup and rollback behavior remain.
- Does not implement CurseForge API downloads; these require approved API access.


V3.3.0: Expanded TOC metadata parsing (X-Part-Of, dependencies, Wago/WoWI IDs); source inheritance for explicitly declared parent modules; clearer unknown-update statuses. CurseForge automatic API download is NOT enabled.
