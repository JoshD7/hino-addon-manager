@echo off
cd /d "%~dp0"
echo Installing secure Windows certificate support for Hino Addon Manager...
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m pip install --upgrade truststore certifi
) else (
  python -m pip install --upgrade truststore certifi
)
echo.
echo Restart Hino Addon Manager and click Test GitHub.
pause
